# shopify-test-theme

# Run in local host

sudo shopify theme dev --store {store_name} 

Ex : sudo shopify theme dev --store farhan-theme-dev